import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import Nav from '../components/Nav'

export default function PostShift() {
  const navigate = useNavigate()
  const [step, setStep] = useState(1)
  const [done, setDone] = useState(false)

  const stepLabels = ['Role & Type', 'Date & Time', 'Rate & Details', 'Review']

  if (done) {
    return (
      <div className="min-h-screen bg-[#f9f8f6] flex flex-col">
        <Nav />
        <div className="flex-1 flex items-center justify-center px-4">
          <div className="bg-white border border-[#e5e7eb] rounded-2xl p-10 w-full max-w-md text-center">
            <div className="text-5xl mb-4">🎉</div>
            <h1 className="text-2xl font-extrabold text-[#1a1a1a] mb-2">Shift posted!</h1>
            <p className="text-sm text-[#6b7280] mb-8">Your shift is live. Professionals in your area will be notified right away.</p>
            <div className="flex flex-col gap-3">
              <button onClick={() => navigate('/dashboard')} className="w-full bg-[#1a7f5e] hover:bg-[#156649] text-white font-bold py-3 rounded-full text-sm transition">
                Go to dashboard
              </button>
              <button onClick={() => { setStep(1); setDone(false) }} className="w-full bg-white border border-[#e5e7eb] text-[#1a1a1a] font-bold py-3 rounded-full text-sm hover:border-[#1a7f5e] transition">
                Post another shift
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#f9f8f6]">
      <Nav />

      {/* Segmented progress bar */}
      <div className="max-w-lg mx-auto px-4 pt-6 pb-4">
        <div className="flex gap-1.5 mb-2">
          {[1,2,3,4].map(n => (
            <div
              key={n}
              className={`h-1.5 flex-1 rounded-full transition-all duration-300 ${n <= step ? 'bg-[#1a7f5e]' : 'bg-[#e5e7eb]'}`}
            />
          ))}
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[12px] font-semibold text-[#9ca3af]">Step {step} of 4</span>
          <span className="text-[12px] font-bold text-[#1a7f5e]">{stepLabels[step - 1]}</span>
        </div>
      </div>

      <div className="flex items-start justify-center px-4 pb-20">
        <div className="bg-white border border-[#e5e7eb] rounded-2xl p-8 w-full max-w-lg">

          {step === 1 && (
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#9ca3af] mb-2">Step 1 of 4</p>
              <h1 className="text-2xl font-extrabold text-[#1a1a1a] mb-1">Role & shift type</h1>
              <p className="text-sm text-[#6b7280] mb-6">What position do you need filled?</p>
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1a1a1a] mb-3">Role needed</label>
                <div className="grid grid-cols-2 gap-3">
                  {['Dental Hygienist', 'Dental Assistant', 'Front Desk / Admin', 'Treatment Coordinator', 'Sterilization Tech', 'Dentist / Associate'].map(r => (
                    <button key={r} className="px-4 py-3 border-2 border-[#e5e7eb] rounded-xl text-sm font-semibold text-[#6b7280] hover:border-[#1a7f5e] hover:text-[#1a7f5e] transition text-left">
                      {r}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1a1a1a] mb-3">Shift type</label>
                <div className="flex border-2 border-[#e5e7eb] rounded-xl overflow-hidden">
                  <button className="flex-1 py-3 text-sm font-bold bg-[#1a7f5e] text-white transition">Temp shift</button>
                  <button className="flex-1 py-3 text-sm font-bold text-[#6b7280] hover:bg-[#f9f8f6] transition">Permanent job</button>
                </div>
              </div>
              <button onClick={() => setStep(2)} className="w-full bg-[#1a7f5e] hover:bg-[#156649] text-white font-bold py-3 rounded-full text-sm transition">
                Continue →
              </button>
            </div>
          )}

          {step === 2 && (
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#9ca3af] mb-2">Step 2 of 4</p>
              <h1 className="text-2xl font-extrabold text-[#1a1a1a] mb-1">Date & time</h1>
              <p className="text-sm text-[#6b7280] mb-6">When do you need coverage?</p>
              <div className="mb-4">
                <label className="block text-sm font-semibold text-[#1a1a1a] mb-1.5">Date</label>
                <input type="date" className="w-full border border-[#e5e7eb] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#1a7f5e] transition" />
              </div>
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="block text-sm font-semibold text-[#1a1a1a] mb-1.5">Start time</label>
                  <input type="time" className="w-full border border-[#e5e7eb] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#1a7f5e] transition" />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#1a1a1a] mb-1.5">End time</label>
                  <input type="time" className="w-full border border-[#e5e7eb] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#1a7f5e] transition" />
                </div>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1a1a1a] mb-1.5">Lunch break</label>
                <select className="w-full border border-[#e5e7eb] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#1a7f5e] transition bg-white">
                  <option>No lunch break</option>
                  <option>30 minutes</option>
                  <option>60 minutes</option>
                </select>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep(1)} className="flex-1 bg-white border border-[#e5e7eb] text-[#1a1a1a] font-bold py-3 rounded-full text-sm hover:border-[#1a7f5e] transition">← Back</button>
                <button onClick={() => setStep(3)} className="flex-1 bg-[#1a7f5e] hover:bg-[#156649] text-white font-bold py-3 rounded-full text-sm transition">Continue →</button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#9ca3af] mb-2">Step 3 of 4</p>
              <h1 className="text-2xl font-extrabold text-[#1a1a1a] mb-1">Rate & details</h1>
              <p className="text-sm text-[#6b7280] mb-6">Set your rate and any requirements</p>
              <div className="mb-4">
                <label className="block text-sm font-semibold text-[#1a1a1a] mb-1.5">Hourly rate</label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6b7280] font-semibold">$</span>
                  <input type="number" placeholder="52" className="w-full border border-[#e5e7eb] rounded-xl pl-8 pr-4 py-3 text-sm outline-none focus:border-[#1a7f5e] transition" />
                </div>
                <p className="text-xs text-[#1a7f5e] mt-1 font-medium">Market rate for Dental Hygienist: $48 – $65/hr</p>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-semibold text-[#1a1a1a] mb-1.5">Practice software</label>
                <div className="flex flex-wrap gap-2">
                  {['Eaglesoft', 'Dentrix', 'Open Dental', 'Curve Dental'].map(s => (
                    <button key={s} className="px-3 py-1.5 border border-[#e5e7eb] rounded-full text-xs font-semibold text-[#6b7280] hover:border-[#1a7f5e] hover:text-[#1a7f5e] transition">{s}</button>
                  ))}
                </div>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-semibold text-[#1a1a1a] mb-1.5">Notes <span className="text-[#9ca3af] font-normal">(optional)</span></label>
                <textarea placeholder="Any special requirements or info about the shift..." className="w-full border border-[#e5e7eb] rounded-xl px-4 py-3 text-sm outline-none focus:border-[#1a7f5e] transition resize-none h-24" />
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep(2)} className="flex-1 bg-white border border-[#e5e7eb] text-[#1a1a1a] font-bold py-3 rounded-full text-sm hover:border-[#1a7f5e] transition">← Back</button>
                <button onClick={() => setStep(4)} className="flex-1 bg-[#1a7f5e] hover:bg-[#156649] text-white font-bold py-3 rounded-full text-sm transition">Continue →</button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div>
              <p className="text-xs font-bold uppercase tracking-widest text-[#9ca3af] mb-2">Step 4 of 4</p>
              <h1 className="text-2xl font-extrabold text-[#1a1a1a] mb-1">Review & post</h1>
              <p className="text-sm text-[#6b7280] mb-6">Double check everything before posting</p>
              <div className="bg-[#f9f8f6] rounded-2xl p-5 mb-6 flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-[#9ca3af] font-semibold uppercase tracking-widest mb-1">Role</p>
                    <p className="text-sm font-bold text-[#1a1a1a]">Dental Hygienist</p>
                  </div>
                  <button onClick={() => setStep(1)} className="text-xs text-[#1a7f5e] font-semibold">Edit</button>
                </div>
                <div className="h-px bg-[#e5e7eb]"></div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-[#9ca3af] font-semibold uppercase tracking-widest mb-1">Date & Time</p>
                    <p className="text-sm font-bold text-[#1a1a1a]">Mon Mar 17 · 8:00am – 5:00pm</p>
                  </div>
                  <button onClick={() => setStep(2)} className="text-xs text-[#1a7f5e] font-semibold">Edit</button>
                </div>
                <div className="h-px bg-[#e5e7eb]"></div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-[#9ca3af] font-semibold uppercase tracking-widest mb-1">Rate</p>
                    <p className="text-sm font-bold text-[#1a1a1a]">$52/hr</p>
                  </div>
                  <button onClick={() => setStep(3)} className="text-xs text-[#1a7f5e] font-semibold">Edit</button>
                </div>
                <div className="h-px bg-[#e5e7eb]"></div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-[#9ca3af] font-semibold uppercase tracking-widest mb-1">Shift Type</p>
                    <p className="text-sm font-bold text-[#1a1a1a]">Temp shift</p>
                  </div>
                  <button onClick={() => setStep(1)} className="text-xs text-[#1a7f5e] font-semibold">Edit</button>
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={() => setStep(3)} className="flex-1 bg-white border border-[#e5e7eb] text-[#1a1a1a] font-bold py-3 rounded-full text-sm hover:border-[#1a7f5e] transition">← Back</button>
                <button onClick={() => setDone(true)} className="flex-1 bg-[#1a7f5e] hover:bg-[#156649] text-white font-bold py-3 rounded-full text-sm transition">Post shift 🚀</button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  )
}
